// 对象变量声明
var index = 1;//索引
//var value = 4;//行走方向及距离,正数为向前走,负数为向后走,数值代表走的距离,这里默认为4px
var flag = 0;//flag为0时表示可以点击，为1时表示正在移动，鼠标无法点击
var ap_time, go_time;//定时器对象
var start = 0, end = -600, procession = -600;//各种距离变量
var wrap = document.getElementById("wrap");
var prev = document.getElementsByClassName("arrow-left");
var next = document.getElementsByClassName("arrow-right");
var tags = document.getElementsByClassName("tag");
var thumbs = document.getElementsByClassName("thumb");
// 各种函数
// 显示当前索引标签
function showCurrentThumbsandTags() {
 for (var i = 0; i < tags.length; i++) {
  tags[i].className = "tag tag-off";
  thumbs[i].className = "thumb thumb-off";
 }
 if(index > 0) {
  tags[(index-1)%5].className = "tag tag-on";
  thumbs[(index-1)%5].className = "thumb thumb-on";
 }
 else {
  tags[(5-Math.abs(index-1))%5].className = "tag tag-on";
  thumbs[(5-Math.abs(index-1))%5].className = "thumb thumb-on";
 }
}
//滚动效果
function go(value) {
 flag = 1;
 go_time = setInterval(gostep, 1, value);
}
//滚动效果细化
function gostep(value) {
 //console.log(99999,value);
 procession = procession + value;
 wrap.style.left = procession + "px";
 // console.log(value, 888888)
 // console.log(end,procession,"   666");
 // console.log(index);
 // console.log(wrap.style.left);
 // console.log(start);
 // console.log(end);
 // console.log(procession);
 if(procession == end) {
  clearInterval(go_time);
  flag = 0;
  if(index == 6) {
   index = 1;
   start = 0;
   end = -600;
   procession = -600;
   wrap.style.left = -600 + "px";
  }
  if(index == 0) {
   index = 5;
   start = -3600;
   end = -3000;
   procession = -3000;
   wrap.style.left = -3000 + "px";
  }
 }
}
//向前翻页
function prev_pic(value) {
 index--;
 value = Math.abs(value);
 start = end;
 end = start+600;
 go(value);
 showCurrentThumbsandTags();
}
//适应性向前翻页
function adj_prev_pic(value) {
 var multiple = value/4;
 index = index - multiple;
 value = Math.abs(value);
 start = end;
 end = start + 600*multiple;
 go(value);
 showCurrentThumbsandTags();
}
//向后翻页
function next_pic(value) {
 index++;
 value = Math.abs(value)*(-1);
 start = end;
 end = start-600;
 go(value);
 showCurrentThumbsandTags();
}
//适应性向后翻页
function adj_next_pic(value) {
 var multiple = value/4;
 index = index + multiple;
 value = Math.abs(value)*(-1);
 start = end;
 end = start - 600*multiple;
 go(value);
 showCurrentThumbsandTags();
}
//自动播放
function autoplay() {
 ap_time = setInterval(next_pic, 4000, 4);
}
// 各种事件
showCurrentThumbsandTags();
autoplay();
prev[0].onclick = function() {
 if(flag == 0) prev_pic(4);
}
next[0].onclick = function() {
 if(flag == 0) next_pic(4);
}
container.onmouseover = function() {
 clearInterval(ap_time);
}
container.onmouseout = function() {
 autoplay();
}
thumb_bkg.onmouseover = function() {
 clearInterval(ap_time);
}
thumb_bkg.onmouseout = function() {
 autoplay();
}
for (var i = 0; i < tags.length; i++) {
 (function(i){
  tags[i].onclick = function() {
   var distance = (i+1) - index;
   var multiple = Math.abs(distance);
   if(distance > 0) {
    var value = 4*multiple;
    if(flag == 0) {
     adj_next_pic(value);
    }
   }
   else if(distance < 0) {
    var value = 4*multiple;
    if(flag == 0) {
     adj_prev_pic(value);
    }
   }
   showCurrentThumbsandTags();
  }
  thumbs[i].onclick = function() {
   var distance = (i+1) - index;
   var multiple = Math.abs(distance);
   if(distance > 0) {
    var value = 4*multiple;
    if(flag == 0) {
     adj_next_pic(value);
    }
   }
   else if(distance < 0) {
    var value = 4*multiple;
    if(flag == 0) {
     adj_prev_pic(value);
    }
   }
   showCurrentThumbsandTags();
  }
 })(i)
}